package com.example.springboot_restful_webservices.Service;

import java.util.List;

import com.example.springboot_restful_webservices.Entity.User;
import com.example.springboot_restful_webservices.dto.UserDTO;

public interface UserService {
	
	UserDTO createUser(UserDTO user);
	
	UserDTO getUserById(Long userId);
	
	List<User> getAllUsers();
	
//	User updatedUser(User user);
	
	void deleteUser(Long userId);

}
