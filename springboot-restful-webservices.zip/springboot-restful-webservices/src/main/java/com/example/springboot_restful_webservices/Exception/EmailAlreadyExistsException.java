package com.example.springboot_restful_webservices.Exception;

public class EmailAlreadyExistsException extends RuntimeException {
	
	public String message;

	public EmailAlreadyExistsException(String message) {
		super(message);
		
	}

}
