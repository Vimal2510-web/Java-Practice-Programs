package com.example.springboot_restful_webservices.mapper;

import com.example.springboot_restful_webservices.Entity.User;
import com.example.springboot_restful_webservices.dto.UserDTO;

public class UserMapper {
	
	// Convert User JPA Entity to UserData 
	
	public static UserDTO mapToUserDTO (User user) {
		
		UserDTO userDTO = new UserDTO(
				user.getId(),
				user.getFirstName(),
				user.getLastName(),
				user.getEmail());
		return userDTO;
	}
	
	public static User mapToUser (UserDTO userDTO) {
		
		User user = new User(
				userDTO.getId(),
				userDTO.getFirstName(),
				userDTO.getLastName(),
				userDTO.getEmail());
	
		return user;
	}
}
