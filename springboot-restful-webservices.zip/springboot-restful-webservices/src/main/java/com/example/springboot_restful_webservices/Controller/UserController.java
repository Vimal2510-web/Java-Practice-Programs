package com.example.springboot_restful_webservices.Controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.springboot_restful_webservices.Entity.User;
import com.example.springboot_restful_webservices.Service.UserService;
import com.example.springboot_restful_webservices.dto.UserDTO;

import jakarta.validation.Valid;



@RestController

@RequestMapping("api/users")
public class UserController {
	
	@Autowired
	private UserService userService;
	
	// build create REST API
	@PostMapping
	public ResponseEntity<UserDTO> createUser(@Valid @RequestBody UserDTO user){
		
		UserDTO savedUser = userService.createUser(user);
		return new ResponseEntity<> (savedUser, HttpStatus.CREATED);
	}
	
	@GetMapping("{id}")
	public ResponseEntity<UserDTO> getByUserId(@PathVariable("id") Long userId){
		
		UserDTO user = userService.getUserById(userId);
		return new ResponseEntity<> (user, HttpStatus.OK);
	}
	
	@GetMapping
	public ResponseEntity<List<User>> getAllUsers(){
		List<User> users = userService.getAllUsers();
		return new ResponseEntity<>(users, HttpStatus.OK);
	}
	
//	@PutMapping("{id}")
//	public ResponseEntity<User> updateUser(@PathVariable("id") Long userId, @RequestBody User user){
//		user.setId(userId);
//		User updatedUser = userService.updateUser(user);
//		return new ResponseEntity<>(updatedUser, HttpStatus.OK);
//	}
	
	public ResponseEntity<String> deleteUser(@PathVariable("id") Long userId ){
		
		userService.deleteUser(userId);
		return new ResponseEntity<>("User successfully deleted ! ", HttpStatus.OK);
	}
//	@ExceptionHandler(ResourceNotFoundException.class)
//	public ResponseEntity<ErrorDetails> handleResourceNotFoundException(ResourceNotFoundException exception, WebRequest webRequest){
//		
//		ErrorDetails errorDetails = new ErrorDetails(
//				LocalDateTime.now(),exception.getMessage(),webRequest.getDescription(false),"USER_NOT_FOUND");
//		return new ResponseEntity<>(errorDetails,HttpStatus.NOT_FOUND);
//	}

}
