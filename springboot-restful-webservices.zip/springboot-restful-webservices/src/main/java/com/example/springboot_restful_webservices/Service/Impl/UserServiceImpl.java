package com.example.springboot_restful_webservices.Service.Impl;


import java.util.List;
import java.util.Optional;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.springboot_restful_webservices.Entity.User;
import com.example.springboot_restful_webservices.Exception.EmailAlreadyExistsException;
import com.example.springboot_restful_webservices.Exception.ResourceNotFoundException;
import com.example.springboot_restful_webservices.Repository.UserRepository;
import com.example.springboot_restful_webservices.Service.UserService;
import com.example.springboot_restful_webservices.dto.UserDTO;
import com.example.springboot_restful_webservices.mapper.UserMapper;

@Service

public class UserServiceImpl implements UserService{
	
	@Autowired
	private UserRepository userRepository;
	
	private ModelMapper modelMapper;

	public UserDTO createUser(UserDTO userDTO) {
		
		// Convert UserDTO into user JPA Entity 
		
		//User user = UserMapper.mapToUser(userDTO);
		
		Optional<User> optionalUser = userRepository.findByEmail(userDTO.getEmail());
		
		if(optionalUser.isPresent()) {
			throw new EmailAlreadyExistsException ("Email Already Exists for User");
		}
		
		User user = modelMapper.map(userDTO,User.class);
		
		User savedUser = userRepository.save(user);
		
		//Convert User JPA Entity to UserDTO
		
		//UserDTO savedUserDTO = UserMapper.mapToUserDTO(savedUser);
		
		UserDTO savedUserDTO = modelMapper.map(savedUser, UserDTO.class);
		
		return savedUserDTO;
	}

	@Override
	public UserDTO getUserById(Long userId) {
		
		User user = userRepository.findById(userId).orElseThrow(()-> new ResourceNotFoundException ("User","id",userId));
		
		return UserMapper.mapToUserDTO(user);
	}

	@Override
	public List<User> getAllUsers() {
		
		return userRepository.findAll();
	}

	@Override
	public void deleteUser(Long userId) {
		
		User existingUser = userRepository.findById(userId).orElseThrow(
				()-> new ResourceNotFoundException("User","id",userId));
		
		userRepository.deleteById(userId);
		
	}

//	@Override
//	public User updatedUser(User user) {
//		User existingUser = userRepository.findById(user.getId()).get();
//		existingUser.setFirstName(user.getFirstName());
//		existingUser.setLastName(user.getLastName());
//		existingUser.setEmail(user.getEmail());
//		
//		User updatedUser = userRepository.save(existingUser);
//		return updatedUser;
//		
//	}
	
	
	

}
